
import androidx.annotation.StringRes
data class Question(@StringRes val textReID: Int, val answer: Boolean)




