import androidx.annotation.StringRes
data class Score(@StringRes val textReID: Int)

